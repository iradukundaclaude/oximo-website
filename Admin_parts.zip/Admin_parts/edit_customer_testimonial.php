<?php
    include('config/dbcon.php');
    include('includes/header.php');

    if (isset($_GET['customer_testimonial'])) {
        $testimonial = $_GET['customer_testimonial'];

        // Prepare and bind the UPDATE statement
        $update_query = "UPDATE `customer_testimonials` SET `customer_messages`=?, `customer_names`=?, `customer_title`=?, `customer_image`=? WHERE `id`=?";
        $stmt = $conn->prepare($update_query);

        if (
            isset($_POST['insert_member']) &&
            isset($_POST['title']) &&
            isset($_POST['education_degree']) &&
            isset($_POST['customer_testimonial']) &&
            isset($_FILES['customer_image']['name'])
        ) {
            // Retrieve form data
            $title = $_POST['title'];
            $degree = $_POST['education_degree'];
            $testimonial_message = $_POST['customer_testimonial'];
            $image = $_FILES['customer_image']['name'];
            $temp_image = $_FILES['customer_image']['tmp_name'];

            // Move uploaded images to a folder
            move_uploaded_file($temp_image, "testimonial_image/" . $image);

            // Bind parameters to the prepared statement
            $stmt->bind_param('ssssi', $testimonial_message, $title, $degree, $image, $testimonial);

            // Execute the update statement
            $stmt->execute();

            // Check for successful update
            if ($stmt->affected_rows > 0) {
                echo "<script>alert('Customer testimonial updated successfully')</script>";
                echo "<script>window.open('./index2.php','_self')</script>";
            } else {
                echo "Error updating testimonial: " . $conn->error;
            }
        } else {
            echo "Missing or incomplete form data.";
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
?>


<div class="container-fluid px-4">
  <h1 class="mt-4">Admin Dashboard</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item active">OUR TESTIMONIALS</li>
    </ol>
    <!----- stating of inserting master planning projects -------->
    <div class="containerr mt-3">
       <h1 class="text-center">Edit Customer Testimonials</h1>
       <!-- form -->
       <form action="" method="POST"  enctype="multipart/form-data">
           <!-- title -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="title" class="form-label">Title</label>
              <input type="text" name="title" id="title" class="form-control" placeholder="<?php echo $customer_name ?>" autocomplete="off" required="required">
           </div>
           <!-- Education Degree -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="education_degree" class="form-label"> Degree</label>
              <input type="text" name="education_degree" id="title" class="form-control" placeholder="<?php echo $customer_post_title ?>" autocomplete="off" required="required">
           </div> 
           <!-- description -->
           <div class="inputbox">
              <span name="customer_testimonial">Customer Testimonials</span>
              <textarea name="customer_testimonial" required="required"><?php echo $customer_messages ?></textarea>
           </div>         
           <!-- member image1-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image1" class="form-label">Project Image1</label>
               <div class="d-flex">
                   <input type="file" id="customer_image" name="customer_image" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/testimonial_image/<?php echo $image ?>" alt="" class="project-img" name="customer_image">
               </div>
           </div>
           <!--insert button -->
           <div class="form-outline mb-4 w-50 m-auto">
               <input type="submit" name="insert_member" class="btn btn-info mb-3 px-3" value="insert member">
           </div>
       </form>
</div>
<?php
    include('includes/footer.php');
    include('includes/scripts.php');
?>