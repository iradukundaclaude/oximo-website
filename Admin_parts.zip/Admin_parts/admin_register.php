<?php
  include('config/dbcon.php');
  include('includes/header.php');
  include('config/dbcon.php');
  include('common_admin_functions/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
        <!-- bootstrap css link-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <style>
           .body{
            background-color: aqua;
           }
        </style>
</head>
<body class="body">
   <div class="container-fluid my-3"> 
      <h2 class="text-center">New User Registration</h2>
      <div class="row d-flex align-items-center justify-content-center">
          <div class="col-lg-12 col-xl-6">
              <form action="" method="POST" enctype="multipart/form-data">
                  <!-- user name field -->
                  <div class="form-outline mb-4">
                      <label for="user_username" class="form-label">Username</label>
                      <input type="text" id="user_username" class="form-control" placeholder="Enter your username" autocomplete="off" required="required" name="user_username">
                  </div>
                  <!-- email field -->
                  <div class="form-outline mb-4">
                      <label for="user_email" class="form-label">Email</label>
                      <input type="email" id="user_email" class="form-control" placeholder="Enter your email" autocomplete="off" required="required" name="user_email">
                  </div>
                  <!-- password field -->
                  <div class="form-outline mb-4">
                      <label for="user_password " class="form-label">Password </label>
                      <input type="password" id="user_password" class="form-control" placeholder="Enter your password " autocomplete="off" required="required" name="user_password">
                  </div>
                  <!--confirm password field -->
                  <div class="form-outline mb-4">
                      <label for="conf_user_password" class="form-label">Confirm Password </label>
                      <input type="password" id="conf_user_password" class="form-control" placeholder="confirm your password" autocomplete="off" required="required" name="conf_user_password">
                  </div>
                   <!-- address field -->
                   <div class="form-outline mb-4">
                      <label for="user_address" class="form-label">Address</label>
                      <input type="text" id="user_address" class="form-control" placeholder="Enter your address" autocomplete="off" required="required" name="user_address">
                  </div>
                  <!-- contact field -->
                  <div class="form-outline mb-4">
                      <label for="user_contact" class="form-label">contact</label>
                      <input type="text" id="user_contact" class="form-control" placeholder="Enter your contact " autocomplete="off" required="required" name="user_contact">
                  </div>
                  <div class="mt-4 pt-2">
                      <input type="submit" value="register" class="bg-info py-2 px-3 boarder-0" name="user_register">
                      <p class="small fw-bold mt-2 pt-1 mb-0">Already have an account ? <a href="admin_login.php" class="text-danger">  login</a></p>
                  </div>
              </form>
          </div>
      </div>
   </div> 
</body>
</html>
<!-- php codes -->
<?php
include('config/dbcon.php');
include('includes/header.php');
if(isset($_POST['user_register'])){
    $user_username = $_POST['user_username'];
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    $conf_user_password = $_POST['conf_user_password'];
    $user_address = $_POST['user_address'];
    $user_contact = $_POST['user_contact'];
    $user_ip = getIPAddress();

    // Validation
    if ($user_password != $conf_user_password) {
        echo "<script>alert('Passwords do not match')</script>";
    } else {
        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT * FROM user_table WHERE user_username=? OR user_email=?");
        $stmt->bind_param("ss", $user_username, $user_email);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows_count = $result->num_rows;

        if($rows_count > 0){
            echo "<script>alert('You have already created account!')</script>";
        } else {
            // Hash the password
            $hash_password = password_hash($user_password, PASSWORD_DEFAULT);

            // Insert query using prepared statements
            $insert_query = $conn->prepare("INSERT INTO user_table (user_username, user_email, user_password, user_ip, user_address, user_contact) VALUES (?, ?, ?, ?, ?, ?)");
            $insert_query->bind_param("ssssss", $user_username, $user_email, $hash_password, $user_ip, $user_address, $user_contact);
            
            if ($insert_query->execute()) {
                echo "<script>alert('Registration successful')</script>";
                echo "<script>window.open('index2.php','_self')</script>";
                // Redirect to login page or perform any other action after successful registration
            } else {
                echo "<script>alert('Registration failed')</script>";
            }
        }
    }
}
?>
<?php
  include('includes/footer.php');
  include('includes/scripts.php');
?>

