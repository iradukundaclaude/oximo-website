<!---- data base connection ---->
<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "oximo";

// Establish connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	header("location:errors/dberror.php");
}
?>

 <?php
 /// view all projects using functions
 function view_allproject(){
     global $conn;        
     if (!isset($_GET['viewmore'])) {
        // Query 1: Fetch data from architecture_project table
        $query1 = "SELECT `id`, `project_description`, `project_keywords`, `project_name`, `location`, `landscale`, `year`, `image1`, `image2`, `image3`, `image4`, `image5`, `date` FROM `architecture_project` ORDER BY id";
        $result1 = $conn->query($query1);

        // Query 2: Fetch data from interior_design table
        $query2 = "SELECT `id`, `project_name`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `date` FROM `interior_design` ORDER BY id";
        $result2 = $conn->query($query2);

        // Query 3: Fetch data from project_management table
        $query3 = "SELECT `id`, `project_description`, `project_keywords`, `project_name`, `location`, `year`, `image1`, `image2`, `date` FROM `project_management` ORDER BY id";
        $result3 = $conn->query($query3);
        // Query 4: Fetch data from master planning table
        $query4 = "SELECT `id`, `project_name`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `date` FROM `master_planning` ORDER BY id";
        $result4 = $conn->query($query4);
        // Query 5: Fetch data from engineering table
        $query5 = "SELECT `id`, `project_title`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `image3`, `date` FROM `engineering_project` ORDER BY id";
        $result5 = $conn->query($query5);

        // Display data from Query 1 (architecture_project)
        if ($result1->num_rows > 0) {
            while ($row = $result1->fetch_assoc()) {
                $project_id=$row['id'];
                $project_title = $row['project_name'];
                $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords = $row['project_keywords'];
                $project_location = $row['location'];
                $project_landscale = $row['landscale'];
                $project_year = $row['year'];
                // Display fetched data from architecture_project
                // You can format the display as per your requirement
                echo " <tr>
                    <th>$project_id</th>
                    <td>$project_title</td>
                    <td>$project_location</td>
                    <td>Architecture</td>
                    <td>$project_year</td>
                    <td><a href='edit_architecture_project.php?architecture_project_detail=$project_id' class='text-light' name='architecture_project_detail'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                    <td><a href='delete_project.php?delete_project=$project_id' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
                </tr>";
            }
        } else {
           echo "<script>alert('No results found for architecture_project')</script>"; 

        }
        // Display data from Query 2 (interiordesign_project)
        if ($result2->num_rows > 0) {
            while ($row = $result2->fetch_assoc()) {
                $project_id1=$row['id'];
                $project_title = $row['project_name'];
                $project_description1 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords1 = $row['project_keywords'];
                $project_location1 = $row['location'];
                $project_landscale1 = $row['landscale'];
                $project_year1 = $row['year'];
                // Display fetched data from interior design
               
             echo " <tr>
                    <th>$project_id1</th>
                    <td>$project_title</td>
                    <td>$project_location1</td>
                    <td>Interior Design</td>
                    <td>$project_year1</td>
                    <td><a href='edit_interior_design_project.php?edit_interior_project=$project_id1' class='text-light'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                    <td><a href='delete_project.php?delete_interior_project=$project_id1' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
             </tr>";
            }
        } else {
            echo "<script>alert('No results found for interior_design_project')</script>"; 
        }
        
        // Display data from Query 3 (project_management)
        if ($result3->num_rows > 0) {
            while ($row = $result3->fetch_assoc()) {
                $project_id2=$row['id'];
                $project_title2 = $row['project_name'];
                $project_description2 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords2 = $row['project_keywords'];
                $project_location2 = $row['location'];
                $project_year2 = $row['year'];
                // Display fetched data from project_management_project
               
                echo " <tr>
                    <th>$project_id2</th>
                    <td>$project_title2</td>
                    <td>$project_location2</td>
                    <td>Project Management</td>
                    <td>$project_year2</td>
                    <td><a href='edit_project_management.php?edit_project_management=$project_id2' class='text-light'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                    <td><a href='delete_project.php?delete_project_management=$project_id2' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
             </tr>";
            }
        } else {
            echo "<script>alert('No results found for project_management')</script>"; 
        }
        
        // Display data from Query 4 (master planning_project)
        if ($result4->num_rows > 0) {
            while ($row = $result4->fetch_assoc()) {
                $project_id3=$row['id'];
                $project_title3 = $row['project_name'];
                $project_description3 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords3 = $row['project_keywords'];
                $project_location3 = $row['location'];
                $project_landscale3 = $row['landscale'];
                $project_year3 = $row['year'];
                // Display fetched data from master planning_project
              
                echo " <tr>
                    <th>$project_id3</th>
                    <td>$project_title3</td>
                    <td>$project_location3</td>
                    <td>Master Planning</td>
                    <td>$project_year3</td>
                    <td><a href='edit_master_planning_project.php?edit_masteplanning_project=$project_id3' class='text-light'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                    <td><a href='delete_project.php?delete_master_planning_project=$project_id3' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
             </tr>";
            }
        } else {
            echo "<script>alert('No results found for master planning_project')</script>"; 
        }
        
        // Display data from Query 5 (engineering_project)
                $query5 = "SELECT * FROM `engineering_project` ORDER BY id";
                $result5 = $conn->query($query5);
               if($result5->num_rows >0){
                while($row = $result5->fetch_assoc()) {
                    $project_id = $row['id'];
                    $project_title = $row['project_name'];
                    $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
                    $project_keywords = $row['project_keywords'];
                    $project_location = $row['location'];
                    $project_landscape = $row['landscale'];
                    $project_year = $row['year'];
                    echo "<tr>
                            <th>$project_id</th>
                            <td>$project_title</td>
                            <td>$project_location</td>
                            <td>Engineering project</td>
                            <td>$project_year</td>
                            <td><a href='edit_engineering_project.php?engineering_project_detail=$project_id' class='text-light'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                            <td><a href='delete_project.php?delete_engineering_project=$project_id' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
                          </tr>";
                }
            } else {
                echo "<script>alert('No results found')</script>"; 
            }
        }
    }

 
 /// function to view customer testimmonials
 function viewcustomer_testimonials(){
     global $conn;
     if (!isset($_GET['testimonial'])) {
         // Query 1: Fetch data from testimonial table
        $query1 = "SELECT `id`, `customer_messages`, `customer_names`, `customer_title`, `customer_image`, `date` FROM `customer_testimonials` ORDER BY id";
        $result1 = $conn->query($query1);
        // Display data from Query 1 (testimonial table)
        if ($result1->num_rows > 0) {
            while ($row = $result1->fetch_assoc()) {
                $customer_id=$row['id'];
                $customer_name = $row['customer_names'];
                $customer_post_title = $row['customer_title']; 
                $customer_messages = $row['customer_messages'];
                $image = $row['customer_image'];
                // Display fetched data from testimonial
                echo"<tr>
                    <td>$customer_id</td>
                    <td>$customer_name</td>
                    <td>$customer_post_title</td>
                    <td>$customer_messages</td>
                    <td><img src='testimonial_image/$image' class='card-img-top' alt='$customer_name' style='width:90px;height:90px;'></td>
                    <td><a href='edit_customer_testimonial.php?customer_testimonial=$customer_id' class='text-light'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                    <td><a href='delete_project.php?delete_customer_testimonial=$customer_id' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
                </tr>";
            }
        }else {
            echo "<script>alert('No results found for Customer Testimonials')</script>"; 
        }
     }
 }
 /// function to view customer messages
 function viewcustomer_messages(){
     global $conn;
     if (!isset($_GET['allmessages'])) {
         // Query 1: Fetch data from testimonial table
        $query1 = "SELECT `id`, `full_name`, `phone`, `email`, `messages`, `date` FROM `user_message` ORDER BY id";
        $result1 = $conn->query($query1);
        // Display data from Query 1 (testimonial table)
        if ($result1->num_rows > 0) {
            while ($row = $result1->fetch_assoc()) {
                $customer_id=$row['id'];
                $customer_name = $row['full_name'];
                $customer_phone = $row['phone']; 
                $customer_email = $row['email'];
                $customer_messages = $row['messages'];
                $customer_date = $row['date'];
                // Display fetched data from testimonial
                echo"<tr>
                    <td>$customer_id</td>
                    <td>$customer_name</td>
                    <td>$customer_email</td>
                    <td>$customer_phone</td>
                    <td>$customer_messages </td>
                    <td>$customer_date</td>
                    <td><a href='delete_project.php?delete_customer_messages_sent=$customer_id' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
                </tr>";
            }
        }else {
            echo "<script>alert('No results found for Customer Testimonials')</script>"; 
        }
     }
 }
 /// forming function to see team members
function viewteam_member_leadership(){
     global $conn;
     if (!isset($_GET['view_team_member'])) {
         // Query 1: Fetch data from testimonial table
        $query1 = "SELECT `id`, `names`, `degree`, `description`, `image`, `date` FROM `team_member` ORDER BY id";
        $result1 = $conn->query($query1);
        // Display data from Query 1 (testimonial table)
        if ($result1->num_rows > 0) {
            while ($row = $result1->fetch_assoc()) {
                $member_id=$row['id'];
                $member_name = $row['names'];
                $member_degree = $row['degree'];
                $member_description = $row['description'];
                $image = $row['image'];
                // Display fetched data from testimonial
                echo" <tr>
                    <td>$member_id</td>
                    <td>$member_name</td>
                    <td>$member_degree</td>
                    <td>$member_description</td>
                    <td><img src='team_member_images/$image' class='card-img-top' alt='$member_name' style='width:90px;height:90px;'></td>
                    <td><a href='edit_team_member.php?ourleadership=$member_id' class='text-light'><i class='fa-solid fa-pen-to-square' style='color:black;'></i></a></td>
                    <td><a href='delete_project.php?delete_team_member=$member_id' class='text-light'><i class='fa-solid fa-trash' style='color:black;'></i></a></td>
                </tr>";
            }
        }else {
            echo "<script>alert('No results found for team member')</script>"; 
        }
     }
 }
 // get ip address function
function getIPAddress() {
  // whether ip is from the share internet
  if(!empty($_SERVER['HTTP_CLIENT_IP'])){
       $ip =$_SERVER['HTTP_CLIENT_IP'];
  }
  // whether ip is from the proxy
  elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
      $ip =$_SERVER['HTTP_X_FORWARDED_FOR'];
  }
  // whether ip is from the remote address
  else{
    $ip =$_SERVER['REMOTE_ADDR'];
  }
  return $ip;
}
?>