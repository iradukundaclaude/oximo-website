<?php
  include('config/dbcon.php');
?>
<?php
  // delete architecture project
  if(isset($_GET['delete_project'])) {
        $get_project_name=$_GET['delete_project'];
        /// delete architecture project
        $delete_architecture_project="DELETE FROM `architecture_project` WHERE id=$get_project_name";
        $result1=mysqli_query($conn,$delete_architecture_project);
        if($result1) {           
            echo "<script>alert('project deleted successfully')</script>"; 
            echo "<script>window.open('index2.php','_self')</script>";    
        }else{
        echo "<script>alert('there is some error, please try again!')</script>"; 
        }
  }
  /// delete engineering project
  if(isset($_GET['delete_engineering_project'])) {
        $get_project_name=$_GET['delete_engineering_project'];
        /// delete architecture project
        $delete_engineering_project="DELETE FROM `engineering_project` WHERE id=$get_project_name";
        $result4=mysqli_query($conn,$delete_engineering_project);
        if($result4) {           
            echo "<script>alert('project deleted successfully')</script>"; 
            echo "<script>window.open('index2.php','_self')</script>";    
        }else{
        echo "<script>alert('there is some error, please try again!')</script>"; 
        }
  }
  // delete interior design project
  if(isset($_GET['delete_interior_project'])) {
        $get_project_name=$_GET['delete_interior_project'];
        /// delete architecture project
        $delete_interior_project="DELETE FROM `interior_design` WHERE id='$get_project_name'";
        $result2=mysqli_query($conn,$delete_interior_project);
        if($result2) {           
            echo "<script>alert('project deleted successfully')</script>"; 
            echo "<script>window.open('index2.php','_self')</script>";    
        }else{
        echo "<script>alert('there is some error, please try again!')</script>"; 
        }
  }
  // delete master planning project
  if(isset($_GET['delete_master_planning_project'])) {
        $get_project_name=$_GET['delete_master_planning_project'];
        /// delete architecture project
        $delete_masterplanning_project="DELETE FROM `master_planning` WHERE id=$get_project_name";
        $result3=mysqli_query($conn,$delete_masterplanning_project);
        if($result3) {           
            echo "<script>alert('project deleted successfully')</script>"; 
            echo "<script>window.open('index2.php','_self')</script>";    
        }else{
        echo "<script>alert('there is some error, please try again!')</script>"; 
        }
  }
  // delete project management 
  if(isset($_GET['delete_project_management'])) {
        $get_project_name=$_GET['delete_project_management'];
        /// delete architecture project
        $delete_project_management="DELETE FROM `project_management` WHERE id=$get_project_name";
        $result5=mysqli_query($conn,$delete_project_management);
        if($result5) {           
            echo "<script>alert('project deleted successfully')</script>"; 
            echo "<script>window.open('index2.php','_self')</script>";    
        }else{
        echo "<script>alert('there is some error, please try again!')</script>"; 
        }
 }
 // delete team member
if(isset($_GET['delete_team_member'])){
    $delete_team_member=$_GET['delete_team_member'];
    $delete_query="DELETE FROM `team_member` WHERE id=$delete_team_member";
    $result=mysqli_query($conn,$delete_query);
    if($result){
      echo "<script>alert('Team member is been Deleted successfully')</script>";
      echo "<script>window.open('./view_team_member.php','_self')</script>"; 
    }
}
 // delete customer testimonials
if(isset($_GET['delete_customer_testimonial'])){
    $delete_team_member=$_GET['delete_customer_testimonial'];
    $delete_query="DELETE FROM `customer_testimonials` WHERE id=$delete_team_member";
    $result=mysqli_query($conn,$delete_query);
    if($result){
      echo "<script>alert('Testimonial is Deleted successfully')</script>";
      echo "<script>window.open('./view_customer_testimonials.php','_self')</script>"; 
    }
}
/// delete customer messages sent
if(isset($_GET['delete_customer_messages_sent'])){
    $delete_team_member=$_GET['delete_customer_messages_sent'];
    $delete_query="DELETE FROM `customer_testimonials` WHERE id=$delete_team_member";
    $result=mysqli_query($conn,$delete_query);
    if($result){
      echo "<script>alert('Customer message is Deleted successfully')</script>";
      echo "<script>window.open('./customer_message.php','_self')</script>"; 
    }
}
?>