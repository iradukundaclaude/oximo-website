<?php
  include('config/dbcon.php');
  include('includes/header.php');
  include('config/dbcon.php')
?>
<?php 
  if(isset($_GET['edit_project_management'])) {
      $fetch_data=$_GET['edit_project_management'];
      $select_query="SELECT * FROM `project_management` WHERE id=$fetch_data";
      $result_query=mysqli_query($conn,$select_query);
      while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
        $project_keywords = $row['project_keywords'];
        $project_location = $row['location'];
        $project_landscale =$row['project_landscale'];
        $project_year = $row['year'];
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $image1 = $row['image1'];
        $image2 = $row['image2'];
        if(isset($_POST['update_project_management_project'])) {
            // Fetching form data
            $project_title = $_POST['project_title'];
            $project_description = $_POST['project_description']; // Add the name attribute in the textarea
            $project_keywords = $_POST['project_keywords'];
            $project_location = $_POST['project_location'];
            $project_landscale = $_POST['project_landscale'];
            $project_year = $_POST['project_year'];
    
            // Uploading images
            $image1 = $_FILES['project_image1']['name'];
            $image2 = $_FILES['project_image2']['name'];
            $image3 = $_FILES['project_image3']['name'];
    
            // Temporary file paths for images
            $temp_image1 = $_FILES['project_image1']['tmp_name'];
            $temp_image2 = $_FILES['project_image2']['tmp_name'];
            $temp_image3 = $_FILES['project_image3']['tmp_name'];

            // Move uploaded images to a folder
            move_uploaded_file($temp_image1, "all_images/" . $image1);
            move_uploaded_file($temp_image2, "all_images/" . $image2);
            move_uploaded_file($temp_image3, "all_images/" . $image3);
            // Prepare and execute the SQL statement
            $update_query="UPDATE `project_management` SET `project_description`='$project_description',`project_keywords`='$project_keywords',`project_name`='$project_title',`location`='$project_location',`project_landscale`='$project_landscale',`year`='$project_year',`image1`='$image1',`image2`='$image2' WHERE id=$fetch_data";
            $result_update=mysqli_query($conn, $update_query);
            if ($result_update === TRUE) {
            echo "<script>alert('project updated successfully')</script>"; 
            echo "<script>window.open('./index2.php','_self')</script>"; 
        } else {
          echo "Error: " . $insert_query . "<br>" . $conn->error;
        }
      }
  }
  // Close the connection
  $conn->close();
  } 
?>
<div class="container-fluid px-4">
  <h1 class="mt-4">Admin Dashboard</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item active">PROJECT MANAGEMENT SERVICES</li>
    </ol>
    <!----- stating of inserting project management -------->
    <div class="containerr mt-3">
       <h1 class="text-center">Edit Project Management Projects</h1>
       <!-- form -->
       <form action="" method="POST"  enctype="multipart/form-data">
           <!-- title -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_title" class="form-label">project title</label>
              <input type="text" name="project_title" id="project_title" class="form-control" placeholder="<?php echo $project_title ?>" autocomplete="off" required="required">
           </div>
           <!-- description -->
           <div class="inputbox">
              <span name="project_description">Type Your Project description</span>
              <textarea name="project_description" required="required"><?php $project_description ?></textarea>
           </div>
           <!--keyword -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_keywords" class="form-label">project keywords</label>
              <input type="text" name="project_keywords" id="project_keywords" class="form-control" placeholder="<?php echo $project_keywords ?>" autocomplete="off" required="required">
           </div>
           <!-- project location -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_location" class="form-label">project location</label>
              <input type="text" name="project_location" id="project_location" class="form-control" placeholder="<?php echo $project_location ?>" autocomplete="off" required="required">
           </div>
           <!-- project land scale -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_landscale" class="form-label">project landscale</label>
              <input type="text" name="project_landscale" id="project_landscale" class="form-control" placeholder="<?php echo $project_landscale ?>" autocomplete="off" required="required">
           </div>
           <!-- project year of published -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_year" class="form-label">project year</label>
              <input type="text" name="project_year" id="project_year" class="form-control" placeholder="<?php echo $project_year ?>" autocomplete="off" required="required">
           </div>
             <!--image1-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image1" class="form-label">Project Image1</label>
               <div class="d-flex">
                   <input type="file" id="project_image1" name="project_image1" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/all_images/<?php echo $image1 ?>" alt="" class="project-img">
               </div>
           </div>
           <!--image2-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image2" class="form-label">Project Image2</label>
               <div class="d-flex">
                   <input type="file" id="project_image2" name="project_image2" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/all_images/<?php echo $image2 ?>" alt="" class="project-img">
               </div>
           </div>
           <!--image3-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image3" class="form-label">Project Image3</label>
               <div class="d-flex">
                   <input type="file" id="project_image3" name="project_image3" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/all_images/<?php echo $image3 ?>" alt="" class="project-img">
               </div>
           </div>
           <!--insert button -->
           <div class="form-outline mb-4 w-50 m-auto">
               <input type="submit" name="update_project_management_project" class="btn btn-info mb-3 px-3" value="insert project">
           </div>
       </form>
  </div> 
    <!----- ending of editing project management projects-------->
<?php
  include('includes/footer.php');
  include('includes/scripts.php');
?>