<?php
  include('config/dbcon.php');
  include('includes/header.php');
  include('config/dbcon.php')
?>
<?php
  if(isset($_GET['ourleadership'])) {
        $team_id=$_GET['ourleadership'];
        $select_query="SELECT `id`, `names`, `degree`, `description`, `image` FROM `team_member` WHERE id=$team_id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
            $names=$row['names'];
            $post_or_title = $row['degree'];
            $qualities_description = $row['description'];
            $leader_image = $row['image'];
            if(isset($_POST['insert_member'])) {
                // Get form data
                $title = $_POST['title'];
                $education_degree = $_POST['education_degree'];
                $description = $_POST['member_description']; // Corrected the name attribute
                $image = $_FILES['member_image']['name']; // Assuming image upload is handled properly
                $temp_image = $_FILES['member_image']['tmp_name'];
                // Move uploaded images to a folder
                move_uploaded_file($temp_image, "team_member_images/" . $image);
                $update_query ="UPDATE `team_member` SET `names`='$title',`degree`='$education_degree',`description`='$description',`image`='$image' WHERE id=$team_id";
                $result_update=mysqli_query($conn, $update_query);
                if ($result_update === TRUE) {
                echo "<script>alert('Team member updated successfully')</script>"; 
                echo "<script>window.open('./index2.php','_self')</script>"; 
                } else {
                    echo "Error: " . $insert_query . "<br>" . $conn->error;
                }
            }
            // Close the connection
            $conn->close();
        }
  }
?>
<div class="container-fluid px-4">
  <h1 class="mt-4">Admin Dashboard</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item active">OUR TEAM MEMBER</li>
    </ol>
    <!----- stating of inserting master planning projects -------->
    <div class="containerr mt-3">
       <h1 class="text-center">Edit Team Member</h1>
       <!-- form -->
       <form action="" method="POST"  enctype="multipart/form-data">
           <!-- title -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="title" class="form-label">Title</label>
              <input type="text" name="title" id="title" class="form-control" placeholder="<?php echo $names ?>" autocomplete="off" required="required">
           </div>
           <!-- Education Degree -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="education_degree" class="form-label">Education Degree</label>
              <input type="text" name="education_degree" id="title" class="form-control" placeholder="<?php echo $post_or_title ?>" autocomplete="off" required="required">
           </div> 
           <!-- description -->
           <div class="inputbox">
              <span name="member_description">Member Description</span>
              <textarea name="member_description" required="required"><?php echo $qualities_description ?></textarea>
           </div>         
           <!-- member image1-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image1" class="form-label">Project Image1</label>
               <div class="d-flex">
                   <input type="file" id="project_image1" name="member_image" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/team_member_image/<?php echo $leader_image ?>" alt="" class="project-img">
               </div>
           </div>
           <!--insert button -->
           <div class="form-outline mb-4 w-50 m-auto">
               <input type="submit" name="insert_member" class="btn btn-info mb-3 px-3" value="insert member">
           </div>
       </form>

 </div> 
    <!----- ending of editing team member-------->
<?php
  include('includes/footer.php');
  include('includes/scripts.php');
?>