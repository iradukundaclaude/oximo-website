<?php
  include('config/dbcon.php');
  include('includes/header.php');
  include('config/dbcon.php')
?>
<?php 
  if(isset($_GET['edit_interior_project'])) {
    $interior_data=$_GET['edit_interior_project'];
    $select_query="SELECT * FROM `interior_design` WHERE id=$interior_data";
    $result_query=mysqli_query($conn,$select_query);
    while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
        $project_keywords = $row['project_keywords'];
        $project_location = $row['location'];
        $project_landscale = $row['landscale'];
        $project_year = $row['year'];
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $image1 = $row['image1'];
        $image2 = $row['image2'];
        if(isset($_POST['edit_interior_design_project'])) {
            // Retrieve form data
            $projectTitle = $_POST['project_name'];
            $projectDescription = $_POST['project_description']; // This was missing in your HTML form
            $projectKeywords = $_POST['project_keywords'];
            $projectLocation = $_POST['project_location'];
            $projectLandscale = $_POST['project_landscale'];
            $projectYear = $_POST['project_year'];
            $image1 = $_FILES['project_image1']['name'];
            $image2 = $_FILES['project_image2']['name'];
            // Move uploaded images to a directory (you should set up a directory to store images)
            // Temporary file paths for images
            $temp_image1 = $_FILES['project_image1']['tmp_name'];
            $temp_image2 = $_FILES['project_image2']['tmp_name'];
            // Move uploaded images to a folder
            move_uploaded_file($temp_image1, "all_images/" . $image1);
            move_uploaded_file($temp_image2, "all_images/" . $image2);
            $update_query="UPDATE `interior_design` SET `project_name`='$projectTitle',`project_description`='$projectDescription',`project_keywords`='$projectKeywords',`location`='$projectLocation',`landscale`='$projectLandscale',`year`='$projectYear',`image1`='$image1',`image2`='$image2' WHERE id=$interior_data";
            $result_update=mysqli_query($conn, $update_query);
            if ($result_update === TRUE) {
            echo "<script>alert('project updated successfully')</script>"; 
            echo "<script>window.open('./index2.php','_self')</script>"; 
        } else {
          echo "Error: " . $insert_query . "<br>" . $conn->error;
        }
    }
  }
    // Close the connection
    $conn->close();
  } 
?>
<div class="container-fluid px-4">
  <h1 class="mt-4">Admin Dashboard</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item active">INTERIOR DESIGN SERVICES</li>
    </ol>
    <!----- stating of inserting interior design projects -------->
    <div class="containerr mt-3">
       <h1 class="text-center">Edit Interior Design Project</h1>
       <!-- form -->
       <form action="" method="POST"  enctype="multipart/form-data">
              <!-- title -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_name" class="form-label">project title</label>
              <input type="text" name="project_name" id="project_name" class="form-control" placeholder="<?php echo $project_title ?>" autocomplete="off" required="required">
           </div>
           <!-- description -->
           <div class="inputbox">
              <span name="project_description">Type Your Project description</span>
              <textarea name="project_description" required="required"><?php echo $project_description?></textarea>
           </div>
           <!--keyword -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_keywords" class="form-label">project keywords</label>
              <input type="text" name="project_keywords" id="project_keywords" class="form-control" placeholder="<?php echo $project_keywords ?>" autocomplete="off" required="required">
           </div>
           <!-- project location -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_location" class="form-label">project location</label>
              <input type="text" name="project_location" id="project_location" class="form-control" placeholder="<?php echo $project_location ?>" autocomplete="off" required="required">
           </div>
           <!-- project land scale -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_landscale" class="form-label">project landscale</label>
              <input type="text" name="project_landscale" id="project_landscale" class="form-control" placeholder="<?php echo $project_landscale ?>" autocomplete="off" required="required">
           </div>
           <!-- project year of published -->
           <div class="form-outline mb-4 w-50 m-auto">
              <label for="project_year" class="form-label">project year</label>
              <input type="text" name="project_year" id="project_year" class="form-control" placeholder="<?php echo $project_year ?>" autocomplete="off" required="required">
           </div>
           <!--image1-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image1" class="form-label">Project Image1</label>
               <div class="d-flex">
                   <input type="file" id="project_image1" name="project_image1" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/all_images/<?php echo $image1 ?>" alt="" class="project-img">
               </div>
           </div>
           <!--image2-->
           <div class="form-outline w-50 m-auto mb-4">
               <label for="project_image2" class="form-label">Project Image2</label>
               <div class="d-flex">
                   <input type="file" id="project_image1" name="project_image2" class="form-control w-80 m-auto" required="required">
                   <img src="/oximo websites/Admin_parts/all_images/<?php echo $image2 ?>" alt="" class="project-img">
               </div>
           </div>
           <!--insert button -->
           <div class="form-outline mb-4 w-50 m-auto">
               <input type="submit" name="edit_interior_design_project" class="btn btn-info mb-3 px-3" value="insert project">
           </div>
       </form>
           </div> 
    <!----- ending of editing interior design project -------->
<?php
  include('includes/footer.php');
  include('includes/scripts.php');
?>